# src/data/transforms.py

import albumentations as A
from albumentations.pytorch import ToTensorV2
import cv2

def get_train_transforms(img_size=256):
    """
    Augmentation cho tập Train:
    - Resize về img_size
    - Random lật ngang (Horizontal Flip)
    - Chỉnh sáng tối nhẹ (RandomBrightnessContrast)
    - Normalize & Convert to Tensor
    """
    return A.Compose([
        A.Resize(height=img_size, width=img_size),
        
        # Data Augmentation (Làm khó model để nó khôn hơn)
        A.HorizontalFlip(p=0.5),
        A.RandomBrightnessContrast(p=0.2),
        A.ShiftScaleRotate(shift_limit=0.05, scale_limit=0.05, rotate_limit=15, p=0.3),
        
        # Chuẩn hóa về [0, 1] và convert sang Tensor PyTorch
        A.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)),
        ToTensorV2()
    ], 
    # Khai báo để Albumentations biết ta có xử lý cả Mask và Keypoints
    additional_targets={'mask': 'mask', 'keypoints': 'keypoints'},
    keypoint_params=A.KeypointParams(format='xy', remove_invisible=False))

def get_valid_transforms(img_size=256):
    """
    Transform cho tập Val/Test: Chỉ Resize và Normalize, giữ nguyên ảnh gốc.
    """
    return A.Compose([
        A.Resize(height=img_size, width=img_size),
        A.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)),
        ToTensorV2()
    ],
    additional_targets={'mask': 'mask', 'keypoints': 'keypoints'},
    keypoint_params=A.KeypointParams(format='xy', remove_invisible=False))