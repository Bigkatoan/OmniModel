# src/data/coco_multitask.py

import os
import cv2
import torch
import numpy as np
from torch.utils.data import Dataset
from pycocotools.coco import COCO
from src.utils.tokenizer import BPE_Tokenizer
import albumentations as A
from albumentations.pytorch import ToTensorV2
import contextlib, io

class OmniCOCODataset(Dataset):
    def __init__(self, cfg, split='train', transform=None):
        self.root_dir = cfg['data']['root_dir']
        self.img_dir = os.path.join(self.root_dir, cfg['data']['train_img_dir'])
        self.max_seq_len = cfg['data']['max_seq_len']
        self.img_size = cfg['data']['img_size']
        
        self.tokenizer = BPE_Tokenizer(cfg['data']['tokenizer_path'], self.max_seq_len)
        
        print(f">>> Loading COCO Annotations ({split})...")
        with contextlib.redirect_stdout(io.StringIO()):
            self.coco_cap = COCO(os.path.join(self.root_dir, cfg['data']['train_json']))
            self.coco_seg = COCO(os.path.join(self.root_dir, cfg['data']['seg_json']))
        
        # Index Segmentation Data
        self.cat_ids = self.coco_seg.getCatIds()
        self.cat_to_imgs = {}
        for cat_id in self.cat_ids:
            img_ids = self.coco_seg.getImgIds(catIds=[cat_id])
            if len(img_ids) > 0:
                self.cat_to_imgs[cat_id] = img_ids
        
        # DEBUG: Kiểm tra xem có load được dữ liệu segment không
        total_seg_imgs = sum(len(v) for v in self.cat_to_imgs.values())
        print(f">>> Segment Index: Found {len(self.cat_ids)} classes, {total_seg_imgs} images indexed.")
        if total_seg_imgs == 0:
            raise RuntimeError("CRITICAL: Không tìm thấy ảnh Segmentation nào! Kiểm tra lại file json.")

        self.caption_img_ids = list(sorted(self.coco_cap.imgs.keys()))
        
        # Transforms
        self.base_transform = A.Compose([
            A.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)),
            ToTensorV2()
        ])
        
        self.full_aug = A.Compose([
            A.Resize(self.img_size, self.img_size),
            A.HorizontalFlip(p=0.5),
            A.ColorJitter(p=0.2)
        ], additional_targets={'mask': 'mask'})

        self.crop_aug = A.Compose([
            A.Resize(self.img_size, self.img_size),
            A.HorizontalFlip(p=0.5),
            A.ColorJitter(p=0.2)
        ], additional_targets={'mask': 'mask'})

    def __len__(self):
        return 50000 

    def __getitem__(self, index):
        # --- CHIẾN THUẬT STRICT SAMPLING ---
        # 1. Quyết định Task trước (50/50 cứng)
        target_task = "segment" if np.random.rand() < 0.5 else "caption"
        
        # 2. Retry Loop: Chỉ retry đúng task đã chọn
        for i in range(10): # Thử 10 lần
            try:
                if target_task == "segment":
                    return self._process_segment_task()
                else:
                    return self._process_caption_task()
            except Exception as e:
                # Nếu lỗi, tiếp tục vòng lặp để chọn ảnh KHÁC cùng task
                # print(f"Retry {target_task}: {e}")
                pass
        
        # 3. Nếu xui xẻo quá 10 lần đều lỗi ở Segment -> Bắt buộc fallback sang Caption để không crash
        # Nhưng trường hợp này sẽ rất hiếm nếu data chuẩn
        # print(f"Warning: Failed to load {target_task} 10 times. Fallback to safe caption.")
        return self._get_safe_fallback()

    def _get_safe_fallback(self):
        dummy_img = torch.zeros((3, self.img_size, self.img_size), dtype=torch.float32)
        p_ids, p_mask = self.tokenizer.encode("error fallback")
        return {
            "task_type": "caption",
            "image": dummy_img,
            "prompt_ids": p_ids,
            "prompt_mask": p_mask,
            "target_ids": p_ids,
            "target_mask": torch.zeros((1, self.img_size, self.img_size))
        }

    def _process_caption_task(self):
        img_id = np.random.choice(self.caption_img_ids)
        img_info = self.coco_cap.loadImgs(img_id)[0]
        path = os.path.join(self.img_dir, img_info['file_name'])
        
        image = cv2.imread(path)
        if image is None: raise FileNotFoundError("Bad img")
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        
        ann_ids = self.coco_cap.getAnnIds(imgIds=img_id)
        if not ann_ids: raise ValueError("No ann")
        caption = np.random.choice(self.coco_cap.loadAnns(ann_ids))['caption']
        
        augmented = self.full_aug(image=image, mask=np.zeros((image.shape[0], image.shape[1])))
        final_img = self.base_transform(image=augmented['image'])['image']
        
        p_ids, p_mask = self.tokenizer.encode("Describe this image")
        t_ids, _ = self.tokenizer.encode(caption)
        
        return {
            "task_type": "caption",
            "image": final_img,
            "prompt_ids": p_ids,
            "prompt_mask": p_mask,
            "target_ids": t_ids,
            "target_mask": torch.zeros((1, self.img_size, self.img_size))
        }

    def _process_segment_task(self):
        # 1. Chọn Category ngẫu nhiên
        target_cat_id = np.random.choice(self.cat_ids)
        candidate_imgs = self.cat_to_imgs.get(target_cat_id, [])
        
        # FIX: Nếu class này không có ảnh, raise Error để vòng lặp bên ngoài chọn class khác
        # Tuyệt đối không return caption ở đây
        if not candidate_imgs: 
            raise ValueError(f"Class {target_cat_id} has no images")
        
        img_id = np.random.choice(candidate_imgs)
        img_info = self.coco_seg.loadImgs(img_id)[0]
        path = os.path.join(self.img_dir, img_info['file_name'])
        
        image = cv2.imread(path)
        if image is None: raise FileNotFoundError("Bad img")
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        H, W, _ = image.shape
        
        ann_ids = self.coco_seg.getAnnIds(imgIds=img_id, catIds=[target_cat_id], iscrowd=False)
        if not ann_ids: raise ValueError("No valid mask")
            
        target_ann = np.random.choice(self.coco_seg.loadAnns(ann_ids))
        
        # Logic Crop
        use_full_image = False
        x, y, w, h = target_ann['bbox']
        
        if w < 5 or h < 5: 
            use_full_image = True
        else:
            pad_scale = np.random.uniform(0.1, 0.4)
            pad_x, pad_y = w * pad_scale, h * pad_scale
            x1 = int(max(0, x - pad_x))
            y1 = int(max(0, y - pad_y))
            x2 = int(min(W, x + w + pad_x))
            y2 = int(min(H, y + h + pad_y))
            
            if x2 <= x1 + 5 or y2 <= y1 + 5: 
                use_full_image = True
        
        full_mask = self.coco_seg.annToMask(target_ann)
        
        if not use_full_image:
            crop_img = image[y1:y2, x1:x2]
            crop_mask = full_mask[y1:y2, x1:x2]
            
            if crop_img.size == 0 or crop_mask.size == 0:
                use_full_image = True
            else:
                augmented = self.crop_aug(image=crop_img, mask=crop_mask)
                final_img_np = augmented['image']
                final_mask_np = augmented['mask']
        
        if use_full_image:
            augmented = self.full_aug(image=image, mask=full_mask)
            final_img_np = augmented['image']
            final_mask_np = augmented['mask']

        final_img_tensor = self.base_transform(image=final_img_np)['image']
        final_mask_tensor = torch.tensor(final_mask_np).float().unsqueeze(0)

        cat_name = self.coco_seg.loadCats(target_cat_id)[0]['name']
        p_ids, p_mask = self.tokenizer.encode(f"Find the {cat_name}")

        return {
            "task_type": "segment",
            "image": final_img_tensor,
            "prompt_ids": p_ids,
            "prompt_mask": p_mask,
            "target_mask": final_mask_tensor,
            "target_ids": torch.zeros(self.max_seq_len, dtype=torch.long)
        }