# src/data/caption_dataset.py

import os
import cv2
import torch
import numpy as np
from torch.utils.data import Dataset
from pycocotools.coco import COCO
from src.utils.tokenizer import BPE_Tokenizer
import albumentations as A
from albumentations.pytorch import ToTensorV2
import contextlib, io

class CaptionDataset(Dataset):
    def __init__(self, cfg, split='train'):
        self.root = cfg['data']['root_dir']
        self.img_dir = os.path.join(self.root, cfg['data']['train_img_dir'])
        
        # Load COCO (Suppress logs)
        with contextlib.redirect_stdout(io.StringIO()):
            self.coco = COCO(os.path.join(self.root, cfg['data']['train_json']))
            
        self.ids = list(sorted(self.coco.imgs.keys()))
        self.tokenizer = BPE_Tokenizer(cfg['data']['tokenizer_path'], cfg['data']['max_seq_len'])
        
        img_size = cfg['data']['img_size']
        
        # --- STRONG AUGMENTATION (SimCLR Style) ---
        if split == 'train':
            self.transform = A.Compose([
                # [FIX] Dùng size=(height, width) thay vì height=, width=
                A.RandomResizedCrop(size=(img_size, img_size), scale=(0.5, 1.0), p=1.0),
                
                A.HorizontalFlip(p=0.5),
                A.ShiftScaleRotate(shift_limit=0.05, scale_limit=0.05, rotate_limit=15, p=0.5),
                A.ColorJitter(brightness=0.4, contrast=0.4, saturation=0.4, hue=0.1, p=0.8),
                A.ToGray(p=0.2),
                
                # CoarseDropout cũng có thể cần dùng keyword arguments rõ ràng
                A.CoarseDropout(max_holes=8, max_height=img_size//10, max_width=img_size//10, p=0.3),
                
                A.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)),
                ToTensorV2()
            ])
        else:
            # Validation Transform
            self.transform = A.Compose([
                A.Resize(height=img_size, width=img_size),
                A.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)),
                ToTensorV2()
            ])

    def __len__(self):
        return len(self.ids)

    def __getitem__(self, index):
        # Retry loop
        for _ in range(5):
            try:
                img_id = self.ids[index]
                ann_ids = self.coco.getAnnIds(imgIds=img_id)
                if not ann_ids: raise ValueError("No caption")
                
                # Random caption
                caption = self.coco.loadAnns(ann_ids)[np.random.randint(len(ann_ids))]['caption']
                
                img_info = self.coco.loadImgs(img_id)[0]
                path = os.path.join(self.img_dir, img_info['file_name'])
                
                image = cv2.imread(path)
                if image is None: raise FileNotFoundError("Img None")
                image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
                
                # Augment
                img_tensor = self.transform(image=image)['image']
                
                # Tokenize
                input_ids, mask = self.tokenizer.encode(caption)
                
                return {
                    "image": img_tensor,
                    "input_ids": input_ids,
                    "mask": mask,
                    "raw_text": caption
                }
            except Exception:
                index = np.random.randint(len(self))
        
        # Fallback
        return {
            "image": torch.zeros((3, 224, 224)),
            "input_ids": torch.zeros(32, dtype=torch.long),
            "mask": torch.zeros(32, dtype=torch.long)
        }